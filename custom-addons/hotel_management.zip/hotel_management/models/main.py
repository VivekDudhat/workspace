from odoo import api,fields,models


class HotelMain(models.Model):

    _name = "hotel.main"
    _description = "Hotel"


    
    
