# -*- coding: utf-8 -*-

from . import hotel_resturant
from . import hotel_rooms
from . import main
from . import hotel_room_type
from . import hotel_room_booking
from . import hotel_room_cleaning
from . import hotel_rental
